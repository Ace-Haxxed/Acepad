# KiCad-SSD1306-0.91-OLED-4pin-128x32

KiCad footprint for a 4-pin SSD1306 OLED 128x32 display module based on the following dimensions:

![OLED module dimensions](./dimensions.jpg "OLED module dimensions")
